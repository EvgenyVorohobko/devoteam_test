import { api, LightningElement } from 'lwc';
import retrieveAllRecords from '@salesforce/apex/CustomRelatedListController.retrieveAllRecords';
import Utils from './utils';

export default class CustomRelatedListCmp extends LightningElement {

    @api title;
    @api icon;
    @api recordId;

    showSpinner = true;
    isExistRecords = false;
    resultValues = [];
    nameElement = 'Name';
    idElement = 'Id';
    errorMessage = 'You cannot retrieve this inforamtion. Please, enter to the administrator.';
    displayEmptyData = 'No data to display.';

    connectedCallback() {
        this.retrieveAllRecords();
    }

    retrieveAllRecords() {
        this.showSpinner = true;
        retrieveAllRecords({ recordId: this.recordId })
            .then(response => {
                if (response == null) {
                    Utils.show('ERROR!', this.errorMessage, Utils.TYPE.ERROR);
                    this.showSpinner = false;
                    return;
                }

                let objBs = response[0].objectBs;
                let objCs = response[0].objectCs;

                if (objBs.length === 0) {
                    this.showSpinner = false;
                    return;
                }

                this.isExistRecords = true;
                for (let index = 0; index < objBs.length; index++) {
                    this.resultValues.push({
                        label: objBs[index][this.nameElement],
                        id: `/${objBs[index][this.idElement]}`,
                    });
                }

                for (let index = 0; index < objCs.length; index++) {
                    this.resultValues.push({
                        label: objCs[index][this.nameElement],
                        id: `/${objCs[index][this.idElement]}`,
                    });
                }

                this.resultValues = [...this.resultValues];
                this.showSpinner = false;
            })
            .catch(error => {
                this.showSpinner = false;
                let message = error.message ? error.message : error.body.message;
                Utils.show('ERROR!', message, Utils.TYPE.ERROR);
            });
    }
}